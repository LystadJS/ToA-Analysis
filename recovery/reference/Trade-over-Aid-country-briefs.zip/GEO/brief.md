# Georgia | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $102,111,704 in goods from Georgia and exported $2,135,015,526 in goods to it. Two-way goods trade totaled $2,237,127,230. That was 17.7% higher than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **Georgia - United States of America BIT (1994)** · UNCTAD archive status · In force (1994). First year shown is signature. Entry into force in the source: 10/08/1999. Status is from the archived inventory and may have changed. [Source](https://raw.githubusercontent.com/ogrnz/BITs/88b457211b556988e2659d5cb696ec6f4f84b3c4/data/0-data_cleaned.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2009–2022). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Millennium Challenge Corporation** · Program monitored by MCC. Georgia II [Source](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Export-Import Bank of the United States** · Destination of approved export finance (2009–2020). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Commerce** · Recipient allocation in federal disbursement accounts (2004–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2003–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2007–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Homeland Security** · Recipient allocation in federal disbursement accounts (2008–2013). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2014–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Air Force** · Recipient allocation in federal disbursement accounts (2016–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Army** · Recipient allocation in federal disbursement accounts (2014–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2018). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Navy** · Recipient allocation in federal disbursement accounts (2016–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2006–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2005–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **National Science Foundation** · Recipient allocation in federal disbursement accounts (2002–2005). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Open World Leadership Center** · Recipient allocation in federal disbursement accounts (2008–2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2001–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1992–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Commerce** · Economic assistance obligations recorded (2004–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (1994–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2003–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2007–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Homeland Security** · Economic assistance obligations recorded (2008–2013). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (2014–2017). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1993–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2017). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2006–2011). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2005–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **National Science Foundation** · Economic assistance obligations recorded (2004–2005). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Open World Leadership Center** · Economic assistance obligations recorded (2008–2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (2000–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (1998–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1994–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

MCC reports monitoring values without an observation date. They document reported activity or outcomes. The timing of any change and its attribution remain unknown.

- **Students participating in MCC-supported education activities** · 642 Number (baseline 0) · observation year unreported. Georgia II — 3. STEM Higher Education Project. ITT 51432 Cumulative  | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Georgia II/3. STEM Higher Education Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Students participating in MCC-supported education activities (Female)** · 219 Number (baseline 0) · observation year unreported. Georgia II — 3. STEM Higher Education Project. ITT 51433 Cumulative  | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Georgia II/3. STEM Higher Education Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Students participating in MCC-supported education activities (Male)** · 423 Number (baseline 0) · observation year unreported. Georgia II — 3. STEM Higher Education Project. ITT 51434 Cumulative  | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Georgia II/3. STEM Higher Education Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $89,005,087 across 18 of 18 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $66,057,863 across 26 of 26 records with disclosed amounts.
- PRC adjusted official commitments in 2020 amounted to $1,003,800 across 2 of 3 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $8,474.04 across 1 of 4 records with disclosed amounts.
- **DAI (Georgia)** (2022). The recorded commitment or exposure was $2,000,000. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115501_0.pdf)
- **Shandong Provincial Government provides RMB 60,000 in scholarships to Georgian students for Foreign Students from International Sister Cities program** (2023). The recorded face-value commitment (CLG) was $8,474.04. [Source record](https://china.aiddata.org/projects/108069/)
- CHN sponsor equity at financial close: undisclosed across 0 of 1 listed stakes with dollar disclosures. Ownership percentages are available for 1. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
