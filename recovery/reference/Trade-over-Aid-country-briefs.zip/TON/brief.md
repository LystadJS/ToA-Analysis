# Tonga | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $3,177,543 in goods from Tonga and exported $14,700,394 in goods to it. Two-way goods trade totaled $17,877,937. That was 21.2% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **Department of Defense** · Recipient allocation in federal disbursement accounts (2013–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Homeland Security** · Recipient allocation in federal disbursement accounts (2023–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2002–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Economic assistance obligations recorded (2001–2016). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1999–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (2002–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $1,920,875 across 2 of 2 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $1,225,303 across 4 of 4 records with disclosed amounts.
- PRC adjusted official commitments in 2020 amounted to $13,585,146.45 across 5 of 8 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $559,881.21 across 2 of 8 records with disclosed amounts.
- **Dongguan Municipal Government grants Tonga 20 fishing boat engines worth TOP 900,000 ** (2023). The recorded face-value commitment (CLG) was $383,621.08. [Source record](https://china.aiddata.org/projects/103987/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
