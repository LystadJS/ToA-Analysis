# Moldova, Republic of | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $100,198,643 in goods from Moldova, Republic of and exported $76,159,207 in goods to it. Two-way goods trade totaled $176,357,850. That was 5.4% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **Moldova, Republic of - United States of America BIT (1993)** · UNCTAD archive status · In force (1993). First year shown is signature. Entry into force in the source: 26/11/1994. Status is from the archived inventory and may have changed. [Source](https://raw.githubusercontent.com/ogrnz/BITs/88b457211b556988e2659d5cb696ec6f4f84b3c4/data/0-data_cleaned.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2011–2022). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Millennium Challenge Corporation** · Program monitored by MCC. Moldova [Source](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Commerce** · Recipient allocation in federal disbursement accounts (2004–2016). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2003–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2010–2021). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2008–2012). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2004). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Air Force** · Recipient allocation in federal disbursement accounts (2016–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Army** · Recipient allocation in federal disbursement accounts (2016–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2010–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2007–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **National Science Foundation** · Recipient allocation in federal disbursement accounts (2002–2005). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Open World Leadership Center** · Recipient allocation in federal disbursement accounts (2008–2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2003–2011). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1992–2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Commerce** · Economic assistance obligations recorded (2004–2016). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2001–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2003–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2010–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2008–2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (2004). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1994–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2010–2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2007–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **National Science Foundation** · Economic assistance obligations recorded (2004–2005). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Open World Leadership Center** · Economic assistance obligations recorded (2008–2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1993–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (2003–2011). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1994–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

The source reports a result for a U.S.-linked program. Monitoring and before-and-after observations alone cannot establish how much the program caused.

- **Enterprises that have applied improved techniques** · 77 Number (baseline 0) in 2015. Moldova — 2. Transition to High Value Agriculture Project. ITT 57971 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring · Outcome, Moldova/2. Transition to High Value Agriculture Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Enterprises that have applied improved techniques (Female)** · 10 Number (baseline 0) in 2015. Moldova — 2. Transition to High Value Agriculture Project. ITT 57972 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring · Outcome, Moldova/2. Transition to High Value Agriculture Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Enterprises that have applied improved techniques (Male)** · 67 Number (baseline 0) in 2015. Moldova — 2. Transition to High Value Agriculture Project. ITT 57973 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring · Outcome, Moldova/2. Transition to High Value Agriculture Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $44,853,668 across 14 of 14 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $66,714,232 across 22 of 22 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $2,700,000 across 1 of 1 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $55,120.74 across 1 of 3 records with disclosed amounts.
- **Moldova Gas Supply for Energy Security** (2022). The recorded commitment or exposure was $400,000,000. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115819.pdf)
- **Chinese government provides LEI 1 million to Moldovan government for the renovation of three kindergarten classrooms in 2023** (2023). The recorded face-value commitment (CLG) was $55,120.74. [Source record](https://china.aiddata.org/projects/104653/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results


- **Road fund allocation.** Moldova — 1. Road Rehabilitation Project reported 57,199,779.74 US Dollars. Baseline 35,800,000. Period ending 2015-06-30 . ITT 58035 ActualQ19 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Moldova/1. Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road traffic fatalities.** Moldova — 1. Road Rehabilitation Project reported 4 Number. Period ending 2014-12-31 . ITT 58029 ActualQ17 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Moldova/1. Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Kilometers of roads completed.** Moldova — 1. Road Rehabilitation Project reported 96 Kilometers. Baseline 0. Period ending 2015-09-30 . ITT 58026 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Moldova/1. Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road safety training for children.** Moldova — 1. Road Rehabilitation Project reported 3,284 Number. Baseline 0. Period ending 2015-09-30 . ITT 58036 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Moldova/1. Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road safety training for teachers.** Moldova — 1. Road Rehabilitation Project reported 227 Number. Baseline 0. Period ending 2015-09-30 . ITT 58037 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Moldova/1. Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road safety training for teachers (Female).** Moldova — 1. Road Rehabilitation Project reported 207 Number. Baseline 0. Period ending 2015-09-30 . ITT 58038 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Moldova/1. Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
