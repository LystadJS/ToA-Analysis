# Bolivia, Plurinational State of | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $618,240,859 in goods from Bolivia, Plurinational State of and exported $348,712,190 in goods to it. Two-way goods trade totaled $966,953,049. That was 9.3% higher than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **Bolivia, Plurinational State of - United States of America BIT (1998)** · UNCTAD archive status · Terminated (1998). First year shown is signature. Entry into force in the source: 06/06/2001. Status is from the archived inventory and may have changed. [Source](https://raw.githubusercontent.com/ogrnz/BITs/88b457211b556988e2659d5cb696ec6f4f84b3c4/data/0-data_cleaned.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **Export-Import Bank of the United States** · Destination of approved export finance (2011–2023). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2015). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2007–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2009–2012). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2002–2015). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Transportation** · Recipient allocation in federal disbursement accounts (2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2002–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2005–2011). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Inter-American Foundation** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2007–2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2012). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2001–2004). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1952–2017). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2011–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2008–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2010–2011). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2009–2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (2001–2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1974–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2002–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2005–2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Inter-American Foundation** · Economic assistance obligations recorded (1974–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2007–2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–2015). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (1998–2004). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1952–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Unknown - Historical Greenbook** · Economic assistance obligations recorded (1946–1988). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Bechtel** · Listed infrastructure sponsor (1999). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Duke Energy Corp.** · Listed infrastructure sponsor (2000). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Tenaska energy** · Listed infrastructure sponsor (2000). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $13,181,230 across 10 of 10 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $1,872,580 across 11 of 11 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $73,179,500.5 across 12 of 20 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $566,072.47 across 2 of 12 records with disclosed amounts.
- USA sponsor equity at financial close: undisclosed across 0 of 3 listed stakes with dollar disclosures. Ownership percentages are available for 2. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **Chinese embassy donates computers for the “tablet project” worth RMB 3.3 million to Bolivia** (2023). The recorded face-value commitment (CLG) was $466,072.47. [Source record](https://china.aiddata.org/projects/106475/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
