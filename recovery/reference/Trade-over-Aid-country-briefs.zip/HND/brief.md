# Honduras | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $5,504,088,658 in goods from Honduras and exported $6,951,505,464 in goods to it. Two-way goods trade totaled $12,455,594,122. That was 0.9% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **Honduras - United States of America BIT (1995)** · UNCTAD archive status · In force (1995). First year shown is signature. Entry into force in the source: 11/07/2001. Status is from the archived inventory and may have changed. [Source](https://raw.githubusercontent.com/ogrnz/BITs/88b457211b556988e2659d5cb696ec6f4f84b3c4/data/0-data_cleaned.csv)
- **Dominican Republic–Central America–United States Free Trade Agreement (CAFTA-DR)** · Party to agreement through 2025 (2006). Year of entry into force for this partner. The inventory covers comprehensive U.S. free trade agreements. [Source](https://ustr.gov/trade-agreements/free-trade-agreements/cafta-dr-dominican-republic-central-america-fta)

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (1985–2023). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Export-Import Bank of the United States** · Destination of approved export finance (2007–2025). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Corps of Engineers, Civil** · Recipient allocation in federal disbursement accounts (2013). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Commerce** · Recipient allocation in federal disbursement accounts (2005–2008). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2007–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2008–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Homeland Security** · Recipient allocation in federal disbursement accounts (2017–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2009–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2014–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Army** · Recipient allocation in federal disbursement accounts (2016–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2002–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Navy** · Recipient allocation in federal disbursement accounts (2016–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2002–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Federal Trade Commission** · Recipient allocation in federal disbursement accounts (2010–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Inter-American Foundation** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2005–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Corps of Engineers, Civil** · Economic assistance obligations recorded (2013). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Agriculture** · Economic assistance obligations recorded (1952–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Commerce** · Economic assistance obligations recorded (2005–2008). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2005–2016). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2007–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2008–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Homeland Security** · Economic assistance obligations recorded (2017–2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2009–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (2000–2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1979–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2002–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2002–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Environmental Protection Agency** · Economic assistance obligations recorded (2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Federal Trade Commission** · Economic assistance obligations recorded (2010–2011). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Inter-American Foundation** · Economic assistance obligations recorded (1972–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2005–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–2016). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (2000–2008). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1952–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Unknown - Historical Greenbook** · Economic assistance obligations recorded (1946–1985). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **SFO Enterprises** · Listed infrastructure sponsor (2000). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **SunEdison LLC** · Listed infrastructure sponsor (2014). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Tennessee Valley Infrastructure Group** · Listed infrastructure sponsor (2003). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Terra Group** · Listed infrastructure sponsor (2016). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Texaco** · Listed infrastructure sponsor (1999). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Upower Group** · Listed infrastructure sponsor (2015). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

The source reports a result for a U.S.-linked program. Monitoring and before-and-after observations alone cannot establish how much the program caused.

- **Annual cost savings at Puerto Cortés** · More than 15,000,000 USD per year · observation year unreported. Customs and phytosanitary reforms at Puerto Cortés. Report p. 20. Strict lower bound. Beneficiary incidence and costing method undisclosed. [Program report · Outcome, Printed p. 20, Puerto Cortés](https://raw.githubusercontent.com/nejohnson2/usaid-feed-the-future/6f48bc14d154da79cf88faeb97bc3f1da1bcd0de/docs/annual-reports/USAID3017_FTF-2024-Annual-Report_121624508c.pdf)
- **Reduction in processing time at Puerto Cortés** · 50 percent reduction · observation year unreported. Customs and phytosanitary reforms at Puerto Cortés. Report p. 20. Paperless handling and joint inspections. Baseline hours, observation dates and comparison port undisclosed. [Program report · Outcome, Printed p. 20, Puerto Cortés](https://raw.githubusercontent.com/nejohnson2/usaid-feed-the-future/6f48bc14d154da79cf88faeb97bc3f1da1bcd0de/docs/annual-reports/USAID3017_FTF-2024-Annual-Report_121624508c.pdf)

The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $121,355,736 across 19 of 19 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $121,259,455 across 25 of 25 records with disclosed amounts.
- PRC adjusted official commitments in 2020 amounted to $32,210,000 across 1 of 1 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $265,604.07 across 2 of 2 records with disclosed amounts.
- **Banco Atlántida S.A.** (2023). The recorded commitment or exposure was $80,000,000. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115814.pdf)
- USA sponsor equity at financial close: $43,500,000 across 1 of 6 listed stakes with dollar disclosures. Ownership percentages are available for 5. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- The workbook reports 100% ownership by a sole named sponsor and project equity for 1 additional stake(s). The implied equity is $64,500,000, shown separately from directly disclosed stakes. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- Terra Group had a disclosed equity commitment of $43,500,000 in Genersa and Mecer Solar Power Plants (2016). [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **Chinese Government provides HNL 2,480,000 to Honduras as emergency aid after flooding, December 2023** (2023). The recorded face-value commitment (CLG) was $100,604.07. [Source record](https://china.aiddata.org/projects/107088/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results


- **Annual cost savings at Puerto Cortés.** Customs and phytosanitary reforms at Puerto Cortés reported more than 15,000,000 USD per year. Observation year unreported. Report p. 20. Strict lower bound. Beneficiary incidence and costing method undisclosed. [Program report, Printed p. 20, Puerto Cortés](https://raw.githubusercontent.com/nejohnson2/usaid-feed-the-future/6f48bc14d154da79cf88faeb97bc3f1da1bcd0de/docs/annual-reports/USAID3017_FTF-2024-Annual-Report_121624508c.pdf)

- **Reduction in processing time at Puerto Cortés.** Customs and phytosanitary reforms at Puerto Cortés reported 50 percent reduction. Observation year unreported. Report p. 20. Paperless handling and joint inspections. Baseline hours, observation dates and comparison port undisclosed. [Program report, Printed p. 20, Puerto Cortés](https://raw.githubusercontent.com/nejohnson2/usaid-feed-the-future/6f48bc14d154da79cf88faeb97bc3f1da1bcd0de/docs/annual-reports/USAID3017_FTF-2024-Annual-Report_121624508c.pdf)

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
