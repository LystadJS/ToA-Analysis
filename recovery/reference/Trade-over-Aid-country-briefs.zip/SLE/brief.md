# Sierra Leone | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $50,330,788 in goods from Sierra Leone and exported $117,616,603 in goods to it. Two-way goods trade totaled $167,947,391. That was 16.0% higher than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **African Growth and Opportunity Act (AGOA)** · Eligibility in 2024: Y (2000–2024). Unilateral trade preference. Country-year eligibility and U.S. imports claiming the preference appear in the program and results records. U.S. imports claiming AGOA totaled $2,539,909 in 2024. Claims measure use of the preference. [Source](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2005–2023). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Export-Import Bank of the United States** · Destination of approved export finance (2010–2013). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **African Development Foundation** · Recipient allocation in federal disbursement accounts (2011–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2005–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2012–2013). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2010–2011). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Transportation** · Recipient allocation in federal disbursement accounts (2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2017–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2014–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2009–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2020–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **African Development Foundation** · Economic assistance obligations recorded (1989–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Agriculture** · Economic assistance obligations recorded (1952–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2005–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2012–2013). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2003–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2010–2011). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1991–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2003–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2015–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2013–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1955–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Gates Foundation** · Local grant commitment (2024). Reviewed Foundation grant commitments to locally identified grantees. [Source](https://www.gatesfoundation.org/about/committed-grants)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $38,601,708 across 14 of 14 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $42,621,480 across 24 of 24 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $2,050,060,458.68 across 7 of 10 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $62,370.22 across 2 of 14 records with disclosed amounts.
- **Summa Airports (SL) Limited** (2023). The recorded commitment or exposure was $150,000,000. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000105360.pdf)
- 1 reviewed Gates Foundation grants to local grantees total $1,147,313 in commitments. [Example grant](https://www.gatesfoundation.org/about/committed-grants/2024/10/inv-079339)
- **24th Chinese medical team donates RMB 300,000 in medicines and medical supplies to Sierra Leone-China Friendship Hospital in Freetown** (2023). The recorded face-value commitment (CLG) was $42,370.22. [Source record](https://china.aiddata.org/projects/106800/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

In 2024, U.S. imports from this country claiming AGOA preferences were valued at $2,539,909. Customs values measure preference use. [USITC-derived series](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
