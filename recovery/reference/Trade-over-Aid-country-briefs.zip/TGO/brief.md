# Togo | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $80,746,033 in goods from Togo and exported $241,034,140 in goods to it. Two-way goods trade totaled $321,780,173. That was 10.5% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **African Growth and Opportunity Act (AGOA)** · Eligibility in 2024: Y (2000–2024). Unilateral trade preference. Country-year eligibility and U.S. imports claiming the preference appear in the program and results records. U.S. imports claiming AGOA totaled $69,270,670 in 2024. Claims measure use of the preference. [Source](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2009). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Millennium Challenge Corporation** · Program monitored by MCC. Togo Threshold [Source](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Export-Import Bank of the United States** · Destination of approved export finance (2012–2017). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **African Development Foundation** · Recipient allocation in federal disbursement accounts (2016–2022). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2009–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2004–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2002–2007). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2008). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2016–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2002–2003). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **African Development Foundation** · Economic assistance obligations recorded (1989–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Agriculture** · Economic assistance obligations recorded (1959–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2009–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2004–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (2001–2007). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1992–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2008). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2016–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (2002–2003). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1961–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Chevron** · Listed infrastructure sponsor (2005). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **ContourGlobal** · Listed infrastructure sponsor (2008). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

MCC reports monitoring values without an observation date. They document reported activity or outcomes. The timing of any change and its attribution remain unknown.

- **Internet penetration** · 1.37 Percentage (baseline 1.6) · observation year unreported. Togo Threshold — ICT Project. ITT 64450 Level Universal Service Fund Activity | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Togo Threshold/ICT Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Broadband internet penetration** · 47.73 Percentage (baseline 42.7) · observation year unreported. Togo Threshold — ICT Project. ITT 64454 Level Universal Service Fund Activity | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Togo Threshold/ICT Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Investment in the ICT sector** · 57,333,000,000.00 CFA Francs (baseline 69,870,000,000.0) · observation year unreported. Togo Threshold — ICT Project. ITT 64477 Level Increase Competition Activity | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Togo Threshold/ICT Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $4,628,535 across 6 of 6 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $33,911,386 across 23 of 23 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $32,472,000 across 4 of 10 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $518,959.04 across 2 of 6 records with disclosed amounts.
- **ContourGlobal Togo S.A.** (2009). The recorded commitment or exposure was $146,250,000. [Source record](https://www.dfc.gov/sites/default/files/2019-08/lome_thermal_power_plant.pdf)
- USA sponsor equity at financial close: undisclosed across 0 of 2 listed stakes with dollar disclosures. Ownership percentages are available for 2. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **China provides funding of USD 500,000 for food assistance to Togo in February 2023** (2023). The recorded face-value commitment (CLG) was $500,000. [Source record](https://china.aiddata.org/projects/103966/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

In 2024, U.S. imports from this country claiming AGOA preferences were valued at $69,270,670. Customs values measure preference use. [USITC-derived series](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
