# Portugal | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $6,256,166,897 in goods from Portugal and exported $2,765,622,196 in goods to it. Two-way goods trade totaled $9,021,789,093. That was 7.4% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **Export-Import Bank of the United States** · Destination of approved export finance (2007–2025). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2003). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Commerce** · Recipient allocation in federal disbursement accounts (2009). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2007–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Homeland Security** · Recipient allocation in federal disbursement accounts (2018). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2009–2012). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Transportation** · Recipient allocation in federal disbursement accounts (2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Air Force** · Recipient allocation in federal disbursement accounts (2018). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Army** · Recipient allocation in federal disbursement accounts (2004–2009). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2015–2021). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2010–2019). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1952–2003). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Commerce** · Economic assistance obligations recorded (2009). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2004–2009). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2008–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Homeland Security** · Economic assistance obligations recorded (2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2009–2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (2017). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2016–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1950–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $40,342 across 1 of 1 records with disclosed amounts.
- U.S. all-sector disbursements in 2024 amounted to $150 across 1 of 1 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $249,523,529.42 across 2 of 3 records with disclosed amounts.
- **Bank of China contributes to a €3 billion EUR syndicated sustainability-linked revolving credit facility to EDP – Energias de Portugal, S.A. for refinancing purposes (Linked to Record ID#104153)** (2023). The recorded face-value commitment (CLG) was $124,761,764.71. [Source record](https://china.aiddata.org/projects/104149/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
