# Sweden | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $16,047,608,388 in goods from Sweden and exported $9,253,361,988 in goods to it. Two-way goods trade totaled $25,300,970,376. That was 3.4% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **Export-Import Bank of the United States** · Destination of approved export finance (2007–2012). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2011–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2007–2015). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2009–2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Economic assistance obligations recorded (2010–2015). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2009–2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1949–1955). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Unknown - Historical Greenbook** · Economic assistance obligations recorded (1946–1949). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2015 amounted to $44,000 across 1 of 1 records with disclosed amounts.
- U.S. all-sector disbursements in 2020 amounted to $3,386 across 1 of 1 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $189,479,454.72 across 2 of 2 records with disclosed amounts.
- **Bank of China contributes to €800 million EUR revolving credit facility to SKF for general corporate purposes** (2023). The recorded face-value commitment (CLG) was $86,501,490.2. [Source record](https://china.aiddata.org/projects/103528/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
