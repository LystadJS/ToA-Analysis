# Dominican Republic | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $7,564,858,524 in goods from Dominican Republic and exported $12,905,760,923 in goods to it. Two-way goods trade totaled $20,470,619,447. That was 0.1% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **Dominican Republic–Central America–United States Free Trade Agreement (CAFTA-DR)** · Party to agreement through 2025 (2007). Year of entry into force for this partner. The inventory covers comprehensive U.S. free trade agreements. [Source](https://ustr.gov/trade-agreements/free-trade-agreements/cafta-dr-dominican-republic-central-america-fta)

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2019–2023). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Export-Import Bank of the United States** · Destination of approved export finance (2007–2025). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Commerce** · Recipient allocation in federal disbursement accounts (2007). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2007–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2007–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Homeland Security** · Recipient allocation in federal disbursement accounts (2009–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2009–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Transportation** · Recipient allocation in federal disbursement accounts (2018–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2003–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2005–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Environmental Protection Agency** · Recipient allocation in federal disbursement accounts (2012). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Federal Trade Commission** · Recipient allocation in federal disbursement accounts (2011–2017). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Inter-American Foundation** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1962–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Commerce** · Economic assistance obligations recorded (2007). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2005–2016). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2007–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2007–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Homeland Security** · Economic assistance obligations recorded (2009–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2009–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (1998–2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1988–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Transportation** · Economic assistance obligations recorded (2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2003–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2005–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Environmental Protection Agency** · Economic assistance obligations recorded (2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Federal Trade Commission** · Economic assistance obligations recorded (2011–2017). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Inter-American Foundation** · Economic assistance obligations recorded (1972–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (2001–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1952–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Unknown - Historical Greenbook** · Economic assistance obligations recorded (1946–1965). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **AES Corporation** · Listed infrastructure sponsor (1999–2002). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Carnival Corporation and plc** · Listed infrastructure sponsor (2013). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Caterpillar Inc.** · Listed infrastructure sponsor (2003). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Dominican Energy Holdings LP** · Listed infrastructure sponsor (1999). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Maxon Corp** · Listed infrastructure sponsor (2000). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $64,470,151 across 17 of 17 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $45,055,431 across 28 of 28 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $37,561,990 across 6 of 6 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $105,881,049.43 across 3 of 6 records with disclosed amounts.
- **DAI (Dominican Republic)** (2023). The recorded commitment or exposure was $2,000,000. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115501_0.pdf)
- USA sponsor equity at financial close: undisclosed across 0 of 6 listed stakes with dollar disclosures. Ownership percentages are available for 3. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **Chinese Embassy donates bus and technological equipment to Mauricio Baez Foundation in the Dominican Republic** (2023). The recorded face-value commitment (CLG) was $90,000. [Source record](https://china.aiddata.org/projects/104351/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
