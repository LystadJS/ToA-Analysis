# Uzbekistan | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $574,859,162 in goods from Uzbekistan and exported $474,074,382 in goods to it. Two-way goods trade totaled $1,048,933,544. That was 147.9% higher than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **United States of America - Uzbekistan BIT (1994)** · UNCTAD archive status · Signed (1994). First year shown is signature. Status is from the archived inventory and may have changed. [Source](https://raw.githubusercontent.com/ogrnz/BITs/88b457211b556988e2659d5cb696ec6f4f84b3c4/data/0-data_cleaned.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2011–2022). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Export-Import Bank of the United States** · Destination of approved export finance (2023). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Commerce** · Recipient allocation in federal disbursement accounts (2004–2015). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2010–2019). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2012). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2015–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2020–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **National Science Foundation** · Recipient allocation in federal disbursement accounts (2002–2005). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Open World Leadership Center** · Recipient allocation in federal disbursement accounts (2004). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2005). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1993–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Commerce** · Economic assistance obligations recorded (2004–2015). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (1997–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2003–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2010–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (2015). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1994–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **National Science Foundation** · Economic assistance obligations recorded (2004–2005). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Open World Leadership Center** · Economic assistance obligations recorded (2004). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1993–2005). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (1998–2008). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1994–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $39,421,685 across 11 of 11 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $31,882,666 across 22 of 22 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $658,075,000 across 4 of 4 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $1,290,565,975.44 across 10 of 17 records with disclosed amounts.
- **DAI (Uzbekistan)** (2022). The recorded commitment or exposure was $2,000,000. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115501_0.pdf)
- **China Eximbank provides buyer’s credit loan for Lot 1 & Lot 2 of 2025 Asian Youth Games Project** (2023). The recorded face-value commitment (CLG) was $250,182,050.73. [Source record](https://china.aiddata.org/projects/101352/)
- CHN sponsor equity at financial close: undisclosed across 0 of 1 listed stakes with dollar disclosures. Ownership percentages are available for 1. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
