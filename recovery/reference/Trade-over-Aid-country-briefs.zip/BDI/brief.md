# Burundi | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $8,127,628 in goods from Burundi and exported $4,413,143 in goods to it. Two-way goods trade totaled $12,540,771. That was 24.4% higher than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **African Growth and Opportunity Act (AGOA)** · Eligibility in 2024: N (2000–2024). Unilateral trade preference. Country-year eligibility and U.S. imports claiming the preference appear in the program and results records. U.S. imports claiming AGOA totaled $0 in 2024. Claims measure use of the preference. [Source](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2006–2020). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **African Development Foundation** · Recipient allocation in federal disbursement accounts (2008–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2005–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2007–2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **African Development Foundation** · Economic assistance obligations recorded (1995–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Agriculture** · Economic assistance obligations recorded (1961–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2005–2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2007–2011). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1995–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1973–1994). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1963–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Amped Innovation** · Listed infrastructure sponsor (2023). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $78,888,262 across 12 of 12 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $39,684,062 across 17 of 17 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $9,034,761 across 4 of 14 records with disclosed amounts.
- PRC CLG face-value commitments in 2022 amounted to $115,898,959.88 across 2 of 16 records with disclosed amounts.
- **Gigawatt Global Burundi S.A.** (2020). The recorded commitment or exposure was $11,312,231. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000083105.pdf)
- USA sponsor equity at financial close: undisclosed across 0 of 1 listed stakes with dollar disclosures. Ownership percentages are available for 1. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **MOFCOM provides RMB 390 million grant — via ETCA — for Melchior Ndadaye International Airport Rehabilitation, Extension and Modernization Project (Linked to Record ID#57280)** (2022). The recorded face-value commitment (CLG) was $57,949,479.94. [Source record](https://china.aiddata.org/projects/102387/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

In 2024, U.S. imports from this country claiming AGOA preferences were valued at $0. Customs values measure preference use. [USITC-derived series](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
