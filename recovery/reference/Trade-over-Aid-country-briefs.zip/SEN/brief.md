# Senegal | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $217,915,116 in goods from Senegal and exported $441,688,189 in goods to it. Two-way goods trade totaled $659,603,305. That was 17.7% higher than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
- **Senegal - United States of America BIT (1983)** · UNCTAD archive status · In force (1983). First year shown is signature. Entry into force in the source: 25/10/1990. Status is from the archived inventory and may have changed. [Source](https://raw.githubusercontent.com/ogrnz/BITs/88b457211b556988e2659d5cb696ec6f4f84b3c4/data/0-data_cleaned.csv)
- **African Growth and Opportunity Act (AGOA)** · Eligibility in 2024: Y (2000–2024). Unilateral trade preference. Country-year eligibility and U.S. imports claiming the preference appear in the program and results records. U.S. imports claiming AGOA totaled $55,136,194 in 2024. Claims measure use of the preference. [Source](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2015–2023). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Millennium Challenge Corporation** · Program monitored by MCC. Senegal; Senegal II [Source](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Export-Import Bank of the United States** · Destination of approved export finance (2018–2022). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **African Development Foundation** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2012–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Homeland Security** · Recipient allocation in federal disbursement accounts (2017–2018). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2008). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Army** · Recipient allocation in federal disbursement accounts (2012–2021). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2003–2016). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Navy** · Recipient allocation in federal disbursement accounts (2016–2018). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2002–2022). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Environmental Protection Agency** · Recipient allocation in federal disbursement accounts (2007). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2005–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2002–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **African Development Foundation** · Economic assistance obligations recorded (1989–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Agriculture** · Economic assistance obligations recorded (1962–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2005–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2012–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2003–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Homeland Security** · Economic assistance obligations recorded (2017–2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2008). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1989–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2003–2016). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2002–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Environmental Protection Agency** · Economic assistance obligations recorded (2007). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2005–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (1998–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1961–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **ContourGlobal** · Listed infrastructure sponsor (2014–2017). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Gates Foundation** · Local grant commitment (2025). Reviewed Foundation grant commitments to locally identified grantees. [Source](https://www.gatesfoundation.org/about/committed-grants)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

The source reports a result for a U.S.-linked program. Monitoring and before-and-after observations alone cannot establish how much the program caused.

- **International Roughness Index** · 1.26 Meters per kilometer (baseline 8.1) in 2015. Senegal — Road Rehabilitation Project. ITT 72466 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring · Outcome, Senegal/Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Number of hectares formalized (having a land allocation title and registered)** · 15,246.05 Hectares (baseline 0.0) in 2015. Senegal — Irrigation and Water Resources Management (IWRM) Project. ITT 72470 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring · Outcome, Senegal/Irrigation and Water Resources Management (IWRM) Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Percentage of land disputes resolved** · 63.41 Percentage (baseline 0.0) in 2015. Senegal — Irrigation and Water Resources Management (IWRM) Project. ITT 72471 ActualQ20 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring · Outcome, Senegal/Irrigation and Water Resources Management (IWRM) Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $158,513,740 across 20 of 20 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $280,002,231 across 31 of 31 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $643,185,305.31 across 4 of 9 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $316,067,043.86 across 3 of 8 records with disclosed amounts.
- **UCCMS TA** (2023). The recorded commitment or exposure was $426,100. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115932.pdf)
- 1 reviewed Gates Foundation grants to local grantees total $1,000,028 in commitments. [Example grant](https://www.gatesfoundation.org/about/committed-grants/2025/08/inv-091568)
- USA sponsor equity at financial close: $208,450,000 across 3 of 3 listed stakes with dollar disclosures. Ownership percentages are available for 3. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- ContourGlobal had a disclosed equity commitment of $13,300,000 in Cap des Biches Oil-Fired Power Plant II (2017). [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **China Eximbank provides buyer’s credit loan for Ferlo Region Ecosystem Resilience Project (PREFERLO)** (2023). The recorded face-value commitment (CLG) was $265,600,000. [Source record](https://china.aiddata.org/projects/102931/)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results


- **Road traffic fatalities (non-common).** Senegal — Road Rehabilitation Project reported 43 Number. Baseline 43. Period ending 2014-09-30 . ITT 72544 ActualQ16 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Senegal/Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road traffic fatalities (non-common) (RN2).** Senegal — Road Rehabilitation Project reported 19 Number. Period ending 2014-09-30 . ITT 72732 ActualQ16 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Senegal/Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road traffic fatalities (non-common) (RN2 – Female).** Senegal — Road Rehabilitation Project reported 1 Number. Period ending 2014-09-30 . ITT 72733 ActualQ16 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Senegal/Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road traffic fatalities (non-common) (RN2 – Male).** Senegal — Road Rehabilitation Project reported 18 Number. Period ending 2014-09-30 . ITT 72734 ActualQ16 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Senegal/Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road traffic fatalities (non-common) (RN6).** Senegal — Road Rehabilitation Project reported 24 Number. Period ending 2014-09-30 . ITT 72736 ActualQ16 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Senegal/Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

- **Road traffic fatalities (non-common) (RN6 – Female).** Senegal — Road Rehabilitation Project reported 3 Number. Period ending 2014-09-30 . ITT 72737 ActualQ16 | Quarterly actual. The target is the end-of-program target. Monitoring describes reported change; attribution requires evaluation. [Quarterly program monitoring, Senegal/Road Rehabilitation Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

In 2024, U.S. imports from this country claiming AGOA preferences were valued at $55,136,194. Customs values measure preference use. [USITC-derived series](https://raw.githubusercontent.com/mlarh-16/agoa_data_brief/64a267a104ca67d8685bfdd3ebbdcc692596ff80/output/agoa_imports_by_country_year.csv)

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
