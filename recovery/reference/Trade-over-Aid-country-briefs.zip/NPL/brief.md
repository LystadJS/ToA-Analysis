# Nepal | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $123,771,219 in goods from Nepal and exported $111,953,343 in goods to it. Two-way goods trade totaled $235,724,562. That was 2.0% lower than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2007–2023). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Millennium Challenge Corporation** · Program monitored by MCC. Nepal [Source](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Export-Import Bank of the United States** · Destination of approved export finance (2016–2018). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2002–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2003–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2009–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2001–2011). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2005–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2002–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2012–2020). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Environmental Protection Agency** · Recipient allocation in federal disbursement accounts (2010). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Millennium Challenge Corporation** · Recipient allocation in federal disbursement accounts (2013–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Peace Corps** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1955–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2006–2016). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2009–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (1999–2011). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (1996–2018). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1990–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2002–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2012–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Environmental Protection Agency** · Economic assistance obligations recorded (2010). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Millennium Challenge Corporation** · Economic assistance obligations recorded (2012–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (2001–2005). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1952–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **STM Communications Services** · Listed infrastructure sponsor (2004). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

MCC reports monitoring values without an observation date. They document reported activity or outcomes. The timing of any change and its attribution remain unknown.

- **Export revenue** · 128,315,789 US Dollars (baseline 78,600,000) · observation year unreported. Nepal — Power Sector Project. ITT 65283 Level (cumulative)  | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Nepal/Power Sector Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Exported electricity** · 1,946,000 Megawatt hours (baseline 1,346,000) · observation year unreported. Nepal — Power Sector Project. ITT 65293 Level  | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Nepal/Power Sector Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)
- **Export revenue (Other)** · 128,315,789 US Dollars · observation year unreported. Nepal — Power Sector Project. ITT 65354 Level (cumulative)  | Actual to date. Reporting end date unspecified. [Program monitoring · Outcome, Nepal/Power Sector Project](https://raw.githubusercontent.com/walaaJaradat/Monitoring-Evaluation-Data-Quality-Analysis/033fbcb1ea335aa3fbcd931d34b0158b67395f5d/Monitoring%2C%20Evaluation%20%26%20Data%20Quality%20Analysis.pbix)

The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $123,249,809 across 14 of 14 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $128,862,433 across 26 of 26 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $148,888,062.4 across 12 of 20 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $3,036,404.42 across 4 of 11 records with disclosed amounts.
- **Namlan Khola Hydropower TA** (2023). The recorded commitment or exposure was $1,939,015. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115882.pdf)
- USA sponsor equity at financial close: undisclosed across 0 of 1 listed stakes with dollar disclosures. Ownership percentages are available for 1. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **Chinese Government provides $1.55 million grant — via UNDP-China South-South Cooperation Assistance Fund — for Pandemic Prevention and Green Recovery in Nepal** (2023). The recorded face-value commitment (CLG) was $1,550,000. [Source record](https://china.aiddata.org/projects/102152/)
- AidData reports 5 dated payment observations, 2014–2021. Coverage varies by facility. [Funding records](finance.csv)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
