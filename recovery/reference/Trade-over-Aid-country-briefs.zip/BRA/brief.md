# Brazil | Development finance and trade

Amounts are current U.S. dollars unless a source currency is shown. Reporting windows differ by source. The last fiscal year in a snapshot may be incomplete. Country allocations can fund implementing partners.

## U.S. bilateral goods trade

In 2025, the United States imported $39,881,521,362 in goods from Brazil and exported $54,329,189,664 in goods to it. Two-way goods trade totaled $94,210,711,026. That was 3.2% higher than in 2024.
Calendar years, current U.S. dollars. Services are outside this series. [U.S. Census Bureau](https://www.census.gov/foreign-trade/balance/country.xlsx) · [Annual country values](bilateral_goods.csv)

## Trade agreements, preferences and initiatives

- **Trade over Aid** · Not listed on supplied USUN roster. USUN roster transcribed 19 November 2026. It identifies participation only. Joining dates, contributions and outcomes are unreported. [Source](https://usun.usmission.gov/trade-over-aid/)
No comprehensive U.S. free trade agreement is listed for this jurisdiction in the through-2025 inventory.

## U.S. agencies and organizations

- **U.S. International Development Finance Corporation** · Project in DFC portfolio (2013–2023). Active-project snapshot. The reported instrument can be financing or insurance exposure. [Source](https://www.dfc.gov/our-impact/all-active-projects)
- **Export-Import Bank of the United States** · Destination of approved export finance (2007–2025). Approved, noncancelled authorizations to the named market. U.S. exporters or lenders can receive the proceeds. FY2025 ends in Q3. [Source](https://www.exim.gov/open-government-data)
- **Department of Agriculture** · Recipient allocation in federal disbursement accounts (2003–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Commerce** · Recipient allocation in federal disbursement accounts (2005–2012). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Defense** · Recipient allocation in federal disbursement accounts (2001–2023). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Energy** · Recipient allocation in federal disbursement accounts (2007–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Health and Human Services** · Recipient allocation in federal disbursement accounts (2003–2021). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Homeland Security** · Recipient allocation in federal disbursement accounts (2009–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Justice** · Recipient allocation in federal disbursement accounts (2009–2011). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Labor** · Recipient allocation in federal disbursement accounts (2003–2008). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of State** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Transportation** · Recipient allocation in federal disbursement accounts (2017–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Army** · Recipient allocation in federal disbursement accounts (2013). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Interior** · Recipient allocation in federal disbursement accounts (2002–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of the Treasury** · Recipient allocation in federal disbursement accounts (2006–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Environmental Protection Agency** · Recipient allocation in federal disbursement accounts (2005–2014). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Federal Trade Commission** · Recipient allocation in federal disbursement accounts (2010–2019). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Inter-American Foundation** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Trade and Development Agency** · Recipient allocation in federal disbursement accounts (2001–2024). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **U.S. Agency for International Development** · Recipient allocation in federal disbursement accounts (2001–2025). Net payments attributed to this recipient can fund implementing partners. [Source](https://foreignassistance.gov/data)
- **Department of Agriculture** · Economic assistance obligations recorded (1955–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Commerce** · Economic assistance obligations recorded (2005–2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Defense** · Economic assistance obligations recorded (2013). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Energy** · Economic assistance obligations recorded (2007–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Health and Human Services** · Economic assistance obligations recorded (2003–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Homeland Security** · Economic assistance obligations recorded (2009–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Justice** · Economic assistance obligations recorded (2009–2012). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of Labor** · Economic assistance obligations recorded (1995–2008). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of State** · Economic assistance obligations recorded (1974–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Interior** · Economic assistance obligations recorded (2002–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Department of the Treasury** · Economic assistance obligations recorded (2006–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Environmental Protection Agency** · Economic assistance obligations recorded (2005–2014). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Federal Trade Commission** · Economic assistance obligations recorded (2010–2019). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Inter-American Foundation** · Economic assistance obligations recorded (1974–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Peace Corps** · Economic assistance obligations recorded (1962–1993). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Trade and Development Agency** · Economic assistance obligations recorded (1998–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **U.S. Agency for International Development** · Economic assistance obligations recorded (1952–2020). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **Unknown - Historical Greenbook** · Economic assistance obligations recorded (1946–1982). Greenbook economic obligations, including predecessor agencies where identified. [Source](https://foreignassistance.gov/reports)
- **AES Corp** · Listed infrastructure sponsor (2022). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **AES Corporation** · Listed infrastructure sponsor (1999–2023). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Alcoa** · Listed infrastructure sponsor (2000–2009). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Ashmore Energy International (AEI)** · Listed infrastructure sponsor (1999). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Atlas Renewable Energy** · Listed infrastructure sponsor (2022–2023). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Cargill, Inc.** · Listed infrastructure sponsor (2010–2016). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **ContourGlobal** · Listed infrastructure sponsor (2009–2014). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Cummins Power Geneation** · Listed infrastructure sponsor (2002). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **EIG Global Energy Partners** · Listed infrastructure sponsor (2009–2012). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **El Paso Corporation** · Listed infrastructure sponsor (1999–2002). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Enron** · Listed infrastructure sponsor (2001). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Gas Capital** · Listed infrastructure sponsor (2017). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **General Electric** · Listed infrastructure sponsor (2015). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **MCI** · Listed infrastructure sponsor (1999). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **MDU Resources International** · Listed infrastructure sponsor (2002–2003). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Montana-Dakota Utilities Company** · Listed infrastructure sponsor (2001). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **New Fortress Energy** · Listed infrastructure sponsor (2023). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Scudder Latin American Power Fund** · Listed infrastructure sponsor (2002). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **SoEnergy** · Listed infrastructure sponsor (2016). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Sprint** · Listed infrastructure sponsor (2011). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Stonepeak Infrastructure Partners** · Listed infrastructure sponsor (2018). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Texas Pacific Group** · Listed infrastructure sponsor (2020). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)
- **Tyco International** · Listed infrastructure sponsor (1999). A listed U.S. sponsor has a stake in a project at financial close. Disclosures vary. [Source](https://ppi.worldbank.org/en/ppi)

[Annual contributions by organization and measure](us_contributions.csv) · [Relationship records](us_relationships.csv)

## Evidence of benefit from U.S.-linked programs

No qualifying U.S.-linked outcome or output was found in the reviewed sources. The benefit to this participant is unknown.


The USUN roster supplies no measure of the impact of joining Trade over Aid.

## Financing

- U.S. economic assistance obligations in 2020 amounted to $86,106,908 across 16 of 16 records with disclosed amounts.
- U.S. all-sector disbursements in 2025 amounted to $31,927,303 across 24 of 24 records with disclosed amounts.
- PRC adjusted official commitments in 2021 amounted to $1,903,267,083 across 7 of 11 records with disclosed amounts.
- PRC CLG face-value commitments in 2023 amounted to $2,387,734,733.73 across 42 of 46 records with disclosed amounts.
- **GW1 Management Company S.à.r.l.** (2023). The recorded commitment or exposure was $467,500,000. [Source record](https://www.dfc.gov/sites/default/files/media/documents/9000115893.pdf)
- USA sponsor equity at financial close: $417,630,000 across 9 of 41 listed stakes with dollar disclosures. Ownership percentages are available for 34. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- New Fortress Energy had a disclosed equity commitment of $0 in Barcarena CCGT Power Plant (2023). [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- **CDB provides $500 million loan to BNDES for on-lending purposes in August 2023** (2023). The recorded face-value commitment (CLG) was $500,000,000. [Source record](https://china.aiddata.org/projects/102633/)
- CHN sponsor equity at financial close: $1,592,950,000 across 9 of 31 listed stakes with dollar disclosures. Ownership percentages are available for 30. Coverage includes state-owned sponsors. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- The workbook reports 100% ownership by a sole named sponsor and project equity for 2 additional stake(s). The implied equity is $200,140,000, shown separately from directly disclosed stakes. [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)
- China Three Gorges Corporation had a disclosed equity commitment of $0 in Aventura I Wind Farm (2021). [PPI workbook](https://raw.githubusercontent.com/oad67/ProjectSuccessPredictor/bd9ddf93d48774d66245c8e690a3e030f949dc1e/PPIData_082025.xlsx)

[Annual series](annual_finance.csv) · [Funding amounts and citations](finance.csv) · [Participation and project status](programs.csv)

## Reported host-country results

No project result meets the briefing criteria. The results extract includes any undated monitoring snapshots.

[All indicators, baselines, targets, changes and evidence methods](results.csv)

## Interpretation

Monitoring and reported before/after changes can reflect other reforms and economic conditions. Country-level logistics observations provide context. A comparison-group estimate applies to its evaluated population. Results do not estimate the effect of joining Trade over Aid.

[Finance and logistics charts](country.pdf) · [Country logistics observations](trade_context.csv)
